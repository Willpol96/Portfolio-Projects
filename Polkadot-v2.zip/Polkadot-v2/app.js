const rosterButton = document.querySelector('.roster');
const artistList = document.querySelector('.rosterList');
const polkaLogo = document.querySelector('.intro');

const pdmcLogo = document.querySelector('.pdmc');
const collective = document.querySelector('.collective');
const aboutUs = document.querySelector('.introPara')

const divorceButton = document.querySelector('.divorceHeading')
const divorceParagraph = document.querySelector('.divorcePara')

const bwbButton = document.querySelector('.bwb')
const bwbParagraph = document.querySelector('.bwbParaDisable')


const victoryLapButton = document.querySelector('.victoryLap')
const victoryParagraph = document.querySelector('.victoryPara')


const pencilButton = document.querySelector('.pencil')
const pencilParagraph = document.querySelector('.pencilPara')


const contactButton = document.querySelector('.contact');
const contactForm = document.querySelector('.contactForm')



const socialContainerDivorce = document.querySelector('.divorceSocialContainer')
const socialContainerBwb = document.querySelector('.bwbSocialContainer')
const socialContainerVictory = document.querySelector('.vSocialContainer')
const socialContainerPencil = document.querySelector('.pencilSocialContainer')

const mobileHeaderD = document.querySelector('.mobileHeadingD')
const mobileHeaderBwb = document.querySelector('.mobileHeadingBwb')
const mobileHeaderVL = document.querySelector('.mobileHeadingVL')
const mobileHeaderP = document.querySelector('.mobileHeadingP')






// Roster click

function showRoster() {
    rosterButton.classList.toggle('rosterDisabled')
    artistList.classList.toggle('rosterListActive')
    polkaLogo.classList.toggle('introLoadup')
    contactButton.classList.toggle('contactDisabled')
    pdmcLogo.classList.toggle('pdmcSmall')
    collective.classList.toggle('collectiveSmall')
    aboutUs.classList.toggle('introParaDisable')

    if (contactForm.classList.contains('contactFormVisible')) {
        rosterButton.classList.remove('rosterDisabled')
        contactButton.classList.remove('contactDisabled')
        contactForm.classList.remove('contactFormVisible')
        pdmcLogo.classList.add('pdmcSmall')
        collective.classList.add('collectiveSmall')
        aboutUs.classList.add('introParaDisable')
        polkaLogo.classList.remove('introLoadup')


    }




}

function showDivorce() {

    divorceButton.classList.toggle('divorceActive')
    divorceParagraph.classList.toggle('divorceParaDisabled')
    socialContainerDivorce.classList.toggle('socialContainerDisable')





    if (divorceButton.classList.contains('divorceActive')) {

        divorceButton.classList.remove('bandreserve1')
        divorceButton.classList.remove('bandreserve2')
        divorceButton.classList.remove('bandreserve3')


        divorceParagraph.classList.remove('divorceParaDisabled')
        socialContainerDivorce.classList.remove('socialContainerDisable')


        bwbButton.classList.add('bandreserve1')
        bwbButton.classList.remove('bwbActive')
        bwbParagraph.classList.add('bwbParaDisable')
        socialContainerBwb.classList.add('bwbSocialContainerDisable')

        victoryLapButton.classList.add('bandreserve2')
        victoryLapButton.classList.remove('victoryLapActive')
        victoryParagraph.classList.add('victoryParaDisable')
        socialContainerVictory.classList.add('vSocialContainerDisable')

        pencilButton.classList.add('bandreserve3')
        pencilButton.classList.remove('pencilActive')
        pencilParagraph.classList.add('pencilParaDisable')
        socialContainerPencil.classList.add('pencilSocialContainerDisable')

        mobileHeaderD.classList.add('mobileHeadingOff')
        mobileHeaderBwb.classList.remove('mobileHeadingOff')
        mobileHeaderVL.classList.remove('mobileHeadingOff')
        mobileHeaderP.classList.remove('mobileHeadingOff')
    }

    if (!divorceButton.classList.contains('divorceActive')) {

        divorceParagraph.classList.add('divorceParaDisabled')
        socialContainerDivorce.classList.add('socialContainerDisable')


        bwbButton.classList.remove('bandreserve1')
        bwbButton.classList.remove('bandreserve2')
        bwbButton.classList.remove('bandreserve3')

        victoryLapButton.classList.remove('bandreserve1')
        victoryLapButton.classList.remove('bandreserve2')
        victoryLapButton.classList.remove('bandreserve3')

        pencilButton.classList.remove('bandreserve1')
        pencilButton.classList.remove('bandreserve2')
        pencilButton.classList.remove('bandreserve3')

        mobileHeaderD.classList.remove('mobileHeadingOff')
    }

    if (pencilButton.classList.contains('bandreserve3') && victoryLapButton.classList.contains('bandreserve3')) {
        pencilButton.classList.add('bandreserve2')
        pencilButton.classList.remove('bandreserve3')
    }

    if (victoryLapButton.classList.contains('bandreserve2') && bwbButton.classList.contains('bandreserve2')) {
        bwbButton.classList.add('bandreserve1')
        bwbButton.classList.remove('bandreserve2')
    }

    if (bwbButton.classList.contains('bandreserve1') && pencilButton.contains('bandreserve1')) {
        bwbButton.classList.remove('bandreserve1')
        bwbButton.classList.add('bandreserve2')
    }



}

function showPencil() {

    pencilButton.classList.toggle('pencilActive')
    pencilParagraph.classList.toggle('pencilParaDisable')
    socialContainerPencil.classList.toggle('pencilSocialContainerDisable')

    if (pencilButton.classList.contains('pencilActive')) {

        pencilButton.classList.remove('bandreserve1')
        pencilButton.classList.remove('bandreserve2')
        pencilButton.classList.remove('bandreserve3')
        socialContainerPencil.classList.remove('pencilSocialContainerDisable')
        pencilParagraph.classList.remove('pencilParaDisable')


        divorceButton.classList.add('bandreserve1')
        divorceButton.classList.remove('divorceActive')
        divorceParagraph.classList.add('divorceParaDisabled')
        socialContainerDivorce.classList.add('socialContainerDisable')

        bwbButton.classList.add('bandreserve2')
        bwbButton.classList.remove('bwbActive')
        bwbParagraph.classList.add('bwbParaDisable')
        socialContainerBwb.classList.add('bwbSocialContainerDisable')

        victoryLapButton.classList.add('bandreserve3')
        victoryLapButton.classList.remove('victoryLapActive')
        victoryParagraph.classList.add('victoryParaDisable')
        socialContainerVictory.classList.add('vSocialContainerDisable')

        mobileHeaderD.classList.remove('mobileHeadingOff')
        mobileHeaderBwb.classList.remove('mobileHeadingOff')
        mobileHeaderVL.classList.remove('mobileHeadingOff')
        mobileHeaderP.classList.add('mobileHeadingOff')
    }

    if (!pencilButton.classList.contains('pencilActive')) {

        socialContainerPencil.classList.add('pencilSocialContainerDisable')
        pencilParagraph.classList.add('pencilParaDisable')


        divorceButton.classList.remove('bandreserve1')
        divorceButton.classList.remove('bandreserve2')
        divorceButton.classList.remove('bandreserve3')

        bwbButton.classList.remove('bandreserve1')
        bwbButton.classList.remove('bandreserve2')
        bwbButton.classList.remove('bandreserve3')

        victoryLapButton.classList.remove('bandreserve1')
        victoryLapButton.classList.remove('bandreserve2')
        victoryLapButton.classList.remove('bandreserve3')

        mobileHeaderP.classList.remove('mobileHeadingOff')
    }

}





function showBwb() {

    bwbButton.classList.toggle('bwbActive')
    bwbParagraph.classList.toggle('bwbParaDisable')
    socialContainerBwb.classList.toggle('bwbSocialContainerDisable')

    if (bwbButton.classList.contains('bwbActive')) {

        bwbButton.classList.remove('bandreserve1')
        bwbButton.classList.remove('bandreserve2')
        bwbButton.classList.remove('bandreserve3')
        socialContainerBwb.classList.remove('bwbSocialContainerDisable')
        pencilParagraph.classList.remove('bwbParaDisable')


        divorceButton.classList.add('bandreserve1')
        divorceButton.classList.remove('divorceActive')
        divorceParagraph.classList.add('divorceParaDisabled')
        socialContainerDivorce.classList.add('socialContainerDisable')


        victoryLapButton.classList.add('bandreserve2')
        victoryLapButton.classList.remove('victoryLapActive')
        victoryParagraph.classList.add('victoryParaDisable')
        socialContainerVictory.classList.add('vSocialContainerDisable')

        pencilButton.classList.add('bandreserve3')
        pencilButton.classList.remove('pencilActive')
        pencilParagraph.classList.add('pencilParaDisable')
        socialContainerPencil.classList.add('pencilSocialContainerDisable')

        mobileHeaderD.classList.remove('mobileHeadingOff')
        mobileHeaderBwb.classList.add('mobileHeadingOff')
        mobileHeaderVL.classList.remove('mobileHeadingOff')
        mobileHeaderP.classList.remove('mobileHeadingOff')
    }

    if (!bwbButton.classList.contains('bwbActive')) {

        bwbParagraph.classList.add('bwbParaDisable')
        socialContainerBwb.classList.add('bwbSocialContainerDisable')

        divorceButton.classList.remove('bandreserve1')
        divorceButton.classList.remove('bandreserve2')
        divorceButton.classList.remove('bandreserve3')

        victoryLapButton.classList.remove('bandreserve1')
        victoryLapButton.classList.remove('bandreserve2')
        victoryLapButton.classList.remove('bandreserve3')

        pencilButton.classList.remove('bandreserve1')
        pencilButton.classList.remove('bandreserve2')
        pencilButton.classList.remove('bandreserve3')

        mobileHeaderBwb.classList.remove('mobileHeadingOff')

    }

    if (pencilButton.classList.contains('bandreserve3') && victoryLapButton.classList.contains('bandreserve3')) {
        pencilButton.classList.add('bandreserve1')
        pencilButton.classList.remove('bandreserve3')
    }

    if (pencilButton.classList.contains('bandreserve1') && divorceButton.classList.contains('bandreserve1')) {
        pencilButton.classList.add('bandreserve2')
        pencilButton.classList.remove('bandreserve1')
    }




}

function showVictory() {
    victoryLapButton.classList.toggle('victoryLapActive')
    victoryParagraph.classList.toggle('victoryParaDisable')
    socialContainerVictory.classList.toggle('vSocialContainerDisable')

    if (victoryLapButton.classList.contains('victoryLapActive')) {

        victoryLapButton.classList.remove('bandreserve1')
        victoryLapButton.classList.remove('bandreserve2')
        victoryLapButton.classList.remove('bandreserve3')
        victoryParagraph.classList.remove('victoryParaDisable')
        socialContainerVictory.classList.remove('vSocialContainerDisable')


        divorceButton.classList.add('bandreserve1')
        divorceButton.classList.remove('divorceActive')
        divorceParagraph.classList.add('divorceParaDisabled')
        socialContainerDivorce.classList.add('socialContainerDisable')


        bwbButton.classList.add('bandreserve2')
        bwbButton.classList.remove('bwbActive')
        bwbParagraph.classList.add('bwbParaDisable')
        socialContainerBwb.classList.add('bwbSocialContainerDisable')


        pencilButton.classList.add('bandreserve3')
        pencilButton.classList.remove('pencilActive')
        pencilParagraph.classList.add('pencilParaDisable')
        socialContainerPencil.classList.add('pencilSocialContainerDisable')

        mobileHeaderD.classList.remove('mobileHeadingOff')
        mobileHeaderBwb.classList.remove('mobileHeadingOff')
        mobileHeaderVL.classList.add('mobileHeadingOff')
        mobileHeaderP.classList.remove('mobileHeadingOff')


    }

    if (!victoryLapButton.classList.contains('victoryLapActive')) {

        divorceButton.classList.remove('bandreserve1')
        divorceButton.classList.remove('bandreserve2')
        divorceButton.classList.remove('bandreserve3')

        bwbButton.classList.remove('bandreserve1')
        bwbButton.classList.remove('bandreserve2')
        bwbButton.classList.remove('bandreserve3')


        pencilButton.classList.remove('bandreserve1')
        pencilButton.classList.remove('bandreserve2')
        pencilButton.classList.remove('bandreserve3')

        mobileHeaderVL.classList.remove('mobileHeadingOff')


    }





}




function showContact() {
    contactButton.classList.toggle('contactDisabled')
    polkaLogo.classList.toggle('introLoadup')
    pdmcLogo.classList.toggle('pdmcSmall')
    collective.classList.toggle('collectiveSmall')
    aboutUs.classList.toggle('introParaDisable')
    rosterButton.classList.toggle('rosterDisabled')
    contactForm.classList.toggle('contactFormVisible')


    if (artistList.classList.contains('rosterListActive')) {

        artistList.classList.remove('rosterListActive')
        pdmcLogo.classList.add('pdmcSmall')
        collective.classList.add('collectiveSmall')
        aboutUs.classList.add('introParaDisable')
        polkaLogo.classList.remove('introLoadup')
        rosterButton.classList.remove('rosterDisabled')
        contactButton.classList.remove('contactDisabled')


    }




}














rosterButton.addEventListener('click', showRoster)
divorceButton.addEventListener('click', showDivorce)
bwbButton.addEventListener('click', showBwb)
victoryLapButton.addEventListener('click', showVictory)
pencilButton.addEventListener('click', showPencil)
contactButton.addEventListener('click', showContact)

